package com.example.aimhelper

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin

class AimOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var guideView: GuideView? = null
    private var panel: LinearLayout? = null
    private var angle = 0.0
    private var lineLength = 420f
    private var visible = true
    private lateinit var guideParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        guideView = GuideView()
        guideParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        guideParams.gravity = Gravity.TOP or Gravity.START
        wm.addView(guideView, guideParams)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 10, 10, 10)
            setBackgroundColor(0xDD20242C.toInt())
        }
        val title = TextView(this).apply {
            text = "AIM GUIDE"
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
        }
        controls.addView(title)
        fun button(label: String, action: () -> Unit) {
            controls.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }
        button("Rotate − 5°") { angle -= 5.0; guideView?.invalidate() }
        button("Rotate + 5°") { angle += 5.0; guideView?.invalidate() }
        button("Line −") { lineLength = (lineLength - 30f).coerceAtLeast(60f); guideView?.invalidate() }
        button("Line +") { lineLength = (lineLength + 30f).coerceAtMost(1000f); guideView?.invalidate() }
        button("Show / hide line") { visible = !visible; guideView?.invalidate() }
        button("Close") { stopSelf() }

        panel = controls
        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 160 }
        wm.addView(panel, panelParams)
        controls.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                if (event.action == MotionEvent.ACTION_DOWN) {
                    startX = panelParams.x; startY = panelParams.y
                    touchX = event.rawX; touchY = event.rawY
                    return false
                }
                if (event.action == MotionEvent.ACTION_MOVE) {
                    panelParams.x = startX + (touchX - event.rawX).toInt()
                    panelParams.y = startY + (event.rawY - touchY).toInt()
                    wm.updateViewLayout(panel, panelParams)
                    return true
                }
                return false
            }
        })
    }

    override fun onDestroy() {
        guideView?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        guideView = null
        panel = null
        super.onDestroy()
    }

    private inner class GuideView : View(this@AimOverlayService) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.CYAN
            strokeWidth = 5f
            style = Paint.Style.STROKE
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (!visible) return
            val startX = width * 0.5f
            val startY = height * 0.65f
            val radians = Math.toRadians(angle)
            val endX = startX + cos(radians).toFloat() * lineLength
            val endY = startY - sin(radians).toFloat() * lineLength
            canvas.drawLine(startX, startY, endX, endY, paint)
            paint.style = Paint.Style.FILL
            canvas.drawCircle(endX, endY, 7f, paint)
            paint.style = Paint.Style.STROKE
        }
    }
}
