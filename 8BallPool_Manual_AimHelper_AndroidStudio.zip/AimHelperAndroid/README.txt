8 Ball Pool Manual Aim Helper - Android Studio project

What it does:
- Displays a cyan guide line over other apps.
- Provides buttons to rotate the line in 5-degree steps.
- Adjusts line length and toggles visibility.
- The guide is manually controlled; it does not inspect, automate, or modify 8 Ball Pool.

Build:
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android device.
5. Open Aim Helper, grant "Display over other apps", then tap "Start floating aim guide".

Notes:
- Android 15 may show an overlay permission screen.
- The guide line starts at the center-lower part of the screen. This is a simple starter implementation; screen position can be customized in GuideView.
- Android Studio and Android SDK are required to build the APK.
